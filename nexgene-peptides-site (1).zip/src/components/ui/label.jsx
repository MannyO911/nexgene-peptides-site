export function Label({ children }) {
  return <label className="block text-sm font-medium mb-1">{children}</label>;
}
